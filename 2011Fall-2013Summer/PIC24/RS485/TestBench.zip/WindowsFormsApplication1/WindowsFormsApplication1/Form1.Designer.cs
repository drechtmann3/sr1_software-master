﻿namespace WindowsFormsApplication1
{
    partial class VTB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Send = new System.Windows.Forms.Button();
            this.GBMode = new System.Windows.Forms.GroupBox();
            this.RBRandWPropStruct = new System.Windows.Forms.RadioButton();
            this.RBManual = new System.Windows.Forms.RadioButton();
            this.RBRandData = new System.Windows.Forms.RadioButton();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.Tabs = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.RCorrectP = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.RBaudR = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.RSValidC = new System.Windows.Forms.CheckBox();
            this.RSCorrectP = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.RSBaudR = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.MBinary = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.MData = new System.Windows.Forms.TextBox();
            this.MMessageDL = new System.Windows.Forms.TextBox();
            this.MMessageT = new System.Windows.Forms.TextBox();
            this.MAddress = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.MAutoDL = new System.Windows.Forms.CheckBox();
            this.MSendB = new System.Windows.Forms.CheckBox();
            this.MCorrectP = new System.Windows.Forms.CheckBox();
            this.MValidC = new System.Windows.Forms.CheckBox();
            this.MSendE = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.MBaudR = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.PCB = new System.Windows.Forms.TextBox();
            this.PCAscii = new System.Windows.Forms.TextBox();
            this.COM = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.MSpamRand = new System.Windows.Forms.CheckBox();
            this.GBMode.SuspendLayout();
            this.Tabs.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // Send
            // 
            this.Send.Location = new System.Drawing.Point(270, 472);
            this.Send.Name = "Send";
            this.Send.Size = new System.Drawing.Size(75, 23);
            this.Send.TabIndex = 2;
            this.Send.Text = "Send";
            this.Send.UseVisualStyleBackColor = true;
            this.Send.Click += new System.EventHandler(this.button1_Click);
            // 
            // GBMode
            // 
            this.GBMode.Controls.Add(this.RBRandWPropStruct);
            this.GBMode.Controls.Add(this.RBManual);
            this.GBMode.Controls.Add(this.RBRandData);
            this.GBMode.Location = new System.Drawing.Point(12, 12);
            this.GBMode.Name = "GBMode";
            this.GBMode.Size = new System.Drawing.Size(200, 100);
            this.GBMode.TabIndex = 3;
            this.GBMode.TabStop = false;
            this.GBMode.Text = "Mode";
            // 
            // RBRandWPropStruct
            // 
            this.RBRandWPropStruct.AutoSize = true;
            this.RBRandWPropStruct.Location = new System.Drawing.Point(7, 43);
            this.RBRandWPropStruct.Name = "RBRandWPropStruct";
            this.RBRandWPropStruct.Size = new System.Drawing.Size(165, 17);
            this.RBRandWPropStruct.TabIndex = 2;
            this.RBRandWPropStruct.TabStop = true;
            this.RBRandWPropStruct.Text = "Random with Proper structure";
            this.RBRandWPropStruct.UseVisualStyleBackColor = true;
            this.RBRandWPropStruct.CheckedChanged += new System.EventHandler(this.RBRandWPropStruct_CheckedChanged);
            // 
            // RBManual
            // 
            this.RBManual.AutoSize = true;
            this.RBManual.Location = new System.Drawing.Point(7, 66);
            this.RBManual.Name = "RBManual";
            this.RBManual.Size = new System.Drawing.Size(86, 17);
            this.RBManual.TabIndex = 1;
            this.RBManual.TabStop = true;
            this.RBManual.Text = "Manual Data";
            this.RBManual.UseVisualStyleBackColor = true;
            this.RBManual.CheckedChanged += new System.EventHandler(this.RBManual_CheckedChanged);
            // 
            // RBRandData
            // 
            this.RBRandData.AutoSize = true;
            this.RBRandData.Location = new System.Drawing.Point(7, 20);
            this.RBRandData.Name = "RBRandData";
            this.RBRandData.Size = new System.Drawing.Size(91, 17);
            this.RBRandData.TabIndex = 0;
            this.RBRandData.TabStop = true;
            this.RBRandData.Text = "Random Data";
            this.RBRandData.UseVisualStyleBackColor = true;
            this.RBRandData.CheckedChanged += new System.EventHandler(this.RBRandData_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(218, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Previous Commands ASCII";
            // 
            // Tabs
            // 
            this.Tabs.Controls.Add(this.tabPage2);
            this.Tabs.Controls.Add(this.tabPage1);
            this.Tabs.Controls.Add(this.tabPage3);
            this.Tabs.Controls.Add(this.tabPage4);
            this.Tabs.Location = new System.Drawing.Point(16, 116);
            this.Tabs.Name = "Tabs";
            this.Tabs.SelectedIndex = 0;
            this.Tabs.Size = new System.Drawing.Size(588, 350);
            this.Tabs.TabIndex = 7;
            this.Tabs.SelectedIndexChanged += new System.EventHandler(this.Tabs_TabIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.RCorrectP);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.RBaudR);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(580, 324);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Random";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // RCorrectP
            // 
            this.RCorrectP.AutoSize = true;
            this.RCorrectP.Location = new System.Drawing.Point(243, 166);
            this.RCorrectP.Name = "RCorrectP";
            this.RCorrectP.Size = new System.Drawing.Size(89, 17);
            this.RCorrectP.TabIndex = 10;
            this.RCorrectP.Text = "Correct Parity";
            this.RCorrectP.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(240, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Baud Rate (K)";
            // 
            // RBaudR
            // 
            this.RBaudR.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.RBaudR.Location = new System.Drawing.Point(240, 140);
            this.RBaudR.Name = "RBaudR";
            this.RBaudR.Size = new System.Drawing.Size(100, 20);
            this.RBaudR.TabIndex = 8;
            this.RBaudR.Text = "115.2";
            this.RBaudR.Enter += new System.EventHandler(this.RBaudR_Enter);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.RSBaudR);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(580, 324);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Random W/ Struct";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.RSValidC);
            this.groupBox1.Controls.Add(this.RSCorrectP);
            this.groupBox1.Location = new System.Drawing.Point(256, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(142, 87);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Options";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(6, 38);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(75, 17);
            this.checkBox1.TabIndex = 7;
            this.checkBox1.Text = "Send EOL";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // RSValidC
            // 
            this.RSValidC.AutoSize = true;
            this.RSValidC.Checked = true;
            this.RSValidC.CheckState = System.Windows.Forms.CheckState.Checked;
            this.RSValidC.Location = new System.Drawing.Point(6, 19);
            this.RSValidC.Name = "RSValidC";
            this.RSValidC.Size = new System.Drawing.Size(102, 17);
            this.RSValidC.TabIndex = 2;
            this.RSValidC.Text = "Valid Checksum";
            this.RSValidC.UseVisualStyleBackColor = true;
            // 
            // RSCorrectP
            // 
            this.RSCorrectP.AutoSize = true;
            this.RSCorrectP.Checked = true;
            this.RSCorrectP.CheckState = System.Windows.Forms.CheckState.Checked;
            this.RSCorrectP.Location = new System.Drawing.Point(6, 59);
            this.RSCorrectP.Name = "RSCorrectP";
            this.RSCorrectP.Size = new System.Drawing.Size(117, 17);
            this.RSCorrectP.TabIndex = 6;
            this.RSCorrectP.Text = "Send Correct Parity";
            this.RSCorrectP.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(150, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Baud Rate (K)";
            // 
            // RSBaudR
            // 
            this.RSBaudR.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.RSBaudR.Location = new System.Drawing.Point(150, 80);
            this.RSBaudR.Name = "RSBaudR";
            this.RSBaudR.Size = new System.Drawing.Size(100, 20);
            this.RSBaudR.TabIndex = 0;
            this.RSBaudR.Text = "115.2";
            this.RSBaudR.Enter += new System.EventHandler(this.RSBaudR_Enter);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.MBinary);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.MData);
            this.tabPage3.Controls.Add(this.MMessageDL);
            this.tabPage3.Controls.Add(this.MMessageT);
            this.tabPage3.Controls.Add(this.MAddress);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(580, 324);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Manual";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(265, 216);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Binary";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(198, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "Data";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(320, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "Message Data Length";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(320, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Message Type";
            // 
            // MBinary
            // 
            this.MBinary.BackColor = System.Drawing.SystemColors.Menu;
            this.MBinary.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.MBinary.Location = new System.Drawing.Point(6, 232);
            this.MBinary.Multiline = true;
            this.MBinary.Name = "MBinary";
            this.MBinary.ReadOnly = true;
            this.MBinary.Size = new System.Drawing.Size(559, 86);
            this.MBinary.TabIndex = 19;
            this.MBinary.Text = "Separate binary codes by one non binary character ex:\r\n10101010P10100011=10101100" +
                "~\r\nBinary can be sortend ex:\r\n101 = 00000101";
            this.MBinary.Enter += new System.EventHandler(this.MBinary_Enter);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(320, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Address";
            // 
            // MData
            // 
            this.MData.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.MData.Location = new System.Drawing.Point(6, 108);
            this.MData.Multiline = true;
            this.MData.Name = "MData";
            this.MData.Size = new System.Drawing.Size(420, 92);
            this.MData.TabIndex = 17;
            this.MData.Text = "25\r\nYES\r\n86\r\n115\r\nNO";
            this.MData.Enter += new System.EventHandler(this.MData_Enter);
            // 
            // MMessageDL
            // 
            this.MMessageDL.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.MMessageDL.Location = new System.Drawing.Point(6, 58);
            this.MMessageDL.Name = "MMessageDL";
            this.MMessageDL.Size = new System.Drawing.Size(308, 20);
            this.MMessageDL.TabIndex = 16;
            this.MMessageDL.Text = "0012";
            this.MMessageDL.Enter += new System.EventHandler(this.MMessageDL_Enter);
            // 
            // MMessageT
            // 
            this.MMessageT.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.MMessageT.Location = new System.Drawing.Point(6, 32);
            this.MMessageT.Name = "MMessageT";
            this.MMessageT.Size = new System.Drawing.Size(308, 20);
            this.MMessageT.TabIndex = 15;
            this.MMessageT.Text = "PING";
            this.MMessageT.Enter += new System.EventHandler(this.MMessageT_Enter);
            // 
            // MAddress
            // 
            this.MAddress.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.MAddress.Location = new System.Drawing.Point(6, 6);
            this.MAddress.Name = "MAddress";
            this.MAddress.Size = new System.Drawing.Size(308, 20);
            this.MAddress.TabIndex = 14;
            this.MAddress.Text = "5F";
            this.MAddress.Enter += new System.EventHandler(this.MAddress_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.MSpamRand);
            this.groupBox2.Controls.Add(this.MAutoDL);
            this.groupBox2.Controls.Add(this.MSendB);
            this.groupBox2.Controls.Add(this.MCorrectP);
            this.groupBox2.Controls.Add(this.MValidC);
            this.groupBox2.Controls.Add(this.MSendE);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.MBaudR);
            this.groupBox2.Location = new System.Drawing.Point(432, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(142, 194);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Options";
            // 
            // MAutoDL
            // 
            this.MAutoDL.AutoSize = true;
            this.MAutoDL.Location = new System.Drawing.Point(6, 84);
            this.MAutoDL.Name = "MAutoDL";
            this.MAutoDL.Size = new System.Drawing.Size(104, 17);
            this.MAutoDL.TabIndex = 13;
            this.MAutoDL.Text = "Auto Data Lenth";
            this.MAutoDL.UseVisualStyleBackColor = true;
            this.MAutoDL.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // MSendB
            // 
            this.MSendB.AutoSize = true;
            this.MSendB.Location = new System.Drawing.Point(6, 107);
            this.MSendB.Name = "MSendB";
            this.MSendB.Size = new System.Drawing.Size(83, 17);
            this.MSendB.TabIndex = 10;
            this.MSendB.Text = "Send Binary";
            this.MSendB.UseVisualStyleBackColor = true;
            this.MSendB.CheckedChanged += new System.EventHandler(this.MSendB_CheckedChanged);
            // 
            // MCorrectP
            // 
            this.MCorrectP.AutoSize = true;
            this.MCorrectP.Checked = true;
            this.MCorrectP.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MCorrectP.Location = new System.Drawing.Point(6, 15);
            this.MCorrectP.Name = "MCorrectP";
            this.MCorrectP.Size = new System.Drawing.Size(89, 17);
            this.MCorrectP.TabIndex = 9;
            this.MCorrectP.Text = "Correct Parity";
            this.MCorrectP.UseVisualStyleBackColor = true;
            // 
            // MValidC
            // 
            this.MValidC.AutoSize = true;
            this.MValidC.Checked = true;
            this.MValidC.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MValidC.Location = new System.Drawing.Point(6, 38);
            this.MValidC.Name = "MValidC";
            this.MValidC.Size = new System.Drawing.Size(102, 17);
            this.MValidC.TabIndex = 2;
            this.MValidC.Text = "Valid Checksum";
            this.MValidC.UseVisualStyleBackColor = true;
            // 
            // MSendE
            // 
            this.MSendE.AutoSize = true;
            this.MSendE.Checked = true;
            this.MSendE.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MSendE.Location = new System.Drawing.Point(6, 61);
            this.MSendE.Name = "MSendE";
            this.MSendE.Size = new System.Drawing.Size(75, 17);
            this.MSendE.TabIndex = 6;
            this.MSendE.Text = "Send EOL";
            this.MSendE.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Baud Rate (K)";
            // 
            // MBaudR
            // 
            this.MBaudR.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.MBaudR.Location = new System.Drawing.Point(6, 164);
            this.MBaudR.Name = "MBaudR";
            this.MBaudR.Size = new System.Drawing.Size(100, 20);
            this.MBaudR.TabIndex = 11;
            this.MBaudR.Text = "115.2";
            this.MBaudR.Enter += new System.EventHandler(this.MBaudR_Enter);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.PCB);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(580, 324);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Previous Commands Binary";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // PCB
            // 
            this.PCB.Location = new System.Drawing.Point(4, 4);
            this.PCB.Multiline = true;
            this.PCB.Name = "PCB";
            this.PCB.Size = new System.Drawing.Size(570, 314);
            this.PCB.TabIndex = 0;
            // 
            // PCAscii
            // 
            this.PCAscii.Location = new System.Drawing.Point(221, 21);
            this.PCAscii.Multiline = true;
            this.PCAscii.Name = "PCAscii";
            this.PCAscii.Size = new System.Drawing.Size(379, 89);
            this.PCAscii.TabIndex = 8;
            // 
            // COM
            // 
            this.COM.Location = new System.Drawing.Point(570, 475);
            this.COM.Name = "COM";
            this.COM.Size = new System.Drawing.Size(30, 20);
            this.COM.TabIndex = 11;
            this.COM.Leave += new System.EventHandler(this.COM_Leave);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(533, 478);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "COM";
            // 
            // MSpamRand
            // 
            this.MSpamRand.AutoSize = true;
            this.MSpamRand.Location = new System.Drawing.Point(6, 128);
            this.MSpamRand.Name = "MSpamRand";
            this.MSpamRand.Size = new System.Drawing.Size(85, 17);
            this.MSpamRand.TabIndex = 14;
            this.MSpamRand.Text = "Spam Rand.";
            this.MSpamRand.UseVisualStyleBackColor = true;
            // 
            // VTB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(619, 507);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.COM);
            this.Controls.Add(this.PCAscii);
            this.Controls.Add(this.Tabs);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GBMode);
            this.Controls.Add(this.Send);
            this.Name = "VTB";
            this.Text = "Virtual Test Bench";
            this.GBMode.ResumeLayout(false);
            this.GBMode.PerformLayout();
            this.Tabs.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Send;
        private System.Windows.Forms.GroupBox GBMode;
        private System.Windows.Forms.RadioButton RBRandWPropStruct;
        private System.Windows.Forms.RadioButton RBManual;
        private System.Windows.Forms.RadioButton RBRandData;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl Tabs;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox RSBaudR;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.CheckBox RSValidC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox RBaudR;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox RSCorrectP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox MCorrectP;
        private System.Windows.Forms.CheckBox MValidC;
        private System.Windows.Forms.CheckBox MSendE;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox MBaudR;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox MBinary;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox MData;
        private System.Windows.Forms.TextBox MMessageDL;
        private System.Windows.Forms.TextBox MMessageT;
        private System.Windows.Forms.TextBox MAddress;
        private System.Windows.Forms.CheckBox MSendB;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.CheckBox RCorrectP;
        private System.Windows.Forms.CheckBox MAutoDL;
        private System.Windows.Forms.TextBox PCB;
        private System.Windows.Forms.TextBox PCAscii;
        private System.Windows.Forms.TextBox COM;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox MSpamRand;
    }
}