﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace WindowsFormsApplication1
{
    public partial class VTB : Form
    {


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//------------------------------------------ Global Variables ----------------------------------------------------------//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        bool TabIndexChanging = false;
        bool[] TBInit;


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//------------------------------------------ UI Controls ---------------------------------------------------------------//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        //initalize the form
        public VTB()
        {
            //Initializing form
            InitializeComponent();
            RBManual.Select();
            Tabs.SelectedIndex = 2;
            TBInit = new bool[8];
            for (int i = 0; i < TBInit.Length; i++)
            {
                TBInit[i] = true;
            }
        }


        //change the tab when the radio buttons are change
        private void RBRandWPropStruct_CheckedChanged(object sender, EventArgs e)
        {
            if (TabIndexChanging == false)
            {
                Tabs.SelectedIndex = 1;
            }
        }
        private void RBRandData_CheckedChanged(object sender, EventArgs e)
        {
            if (TabIndexChanging == false)
            {
                Tabs.SelectedIndex = 0;
            }
        }
        private void RBManual_CheckedChanged(object sender, EventArgs e)
        {
            if (TabIndexChanging == false)
            {
                Tabs.SelectedIndex = 2;
            }
        }

        //change the radio button when the tab is changed
        private void Tabs_TabIndexChanged(object sender, EventArgs e)
        {
            if (Tabs.SelectedIndex == 3)
            {
                return;
            }
            else
            {
                switch (Tabs.SelectedIndex)
                {
                    case 0:
                        TabIndexChanging = true;
                        RBRandData.Checked = true;
                        break;
                    case 1:
                        TabIndexChanging = true;
                        RBRandWPropStruct.Checked = true;
                        break;
                    case 2:
                        TabIndexChanging = true;
                        RBManual.Checked = true;
                        break;
                    default:
                        MessageBox.Show("Tab indexing error");
                        break;
                }
                TabIndexChanging = false;
            }
        }


        //delete the inital text when the textbox is entered
        private void RBaudR_Enter(object sender, EventArgs e)
        {
            if (TBInit[0] == true)
            {
                RBaudR.Text = "";
                RBaudR.ForeColor = System.Drawing.Color.Black;
                TBInit[0] = false;
            }
        }
        private void RSBaudR_Enter(object sender, EventArgs e)
        {
            if (TBInit[1] == true)
            {
                RSBaudR.Text = "";
                RSBaudR.ForeColor = System.Drawing.Color.Black;
                TBInit[1] = false;
            }
        }
        private void MAddress_Enter(object sender, EventArgs e)
        {
            if (TBInit[2] == true)
            {
                MAddress.Text = "";
                MAddress.ForeColor = System.Drawing.Color.Black;
                TBInit[2] = false;
            }
        }
        private void MMessageT_Enter(object sender, EventArgs e)
        {
            if (TBInit[3] == true)
            {
                MMessageT.Text = "";
                MMessageT.ForeColor = System.Drawing.Color.Black;
                TBInit[3] = false;
            }
        }
        private void MMessageDL_Enter(object sender, EventArgs e)
        {
            if (TBInit[4] == true)
            {
                MMessageDL.Text = "";
                MMessageDL.ForeColor = System.Drawing.Color.Black;
                TBInit[4] = false;
            }
        }
        private void MData_Enter(object sender, EventArgs e)
        {
            if (TBInit[5] == true)
            {
                MData.Text = "";
                MData.ForeColor = System.Drawing.Color.Black;
                TBInit[5] = false;
            }
        }
        private void MBinary_Enter(object sender, EventArgs e)
        {
            if (TBInit[6] == true)
            {
                MBinary.Text = "";
                MBinary.ForeColor = System.Drawing.Color.Black;
                TBInit[6] = false;
            }
        }
        private void MBaudR_Enter(object sender, EventArgs e)
        {
            if (TBInit[7] == true)
            {
                MBaudR.Text = "";
                MBaudR.ForeColor = System.Drawing.Color.Black;
                TBInit[7] = false;
            }
        }


        //enable and disable controls based on if the manual binary input is selected
        private void MSendB_CheckedChanged(object sender, EventArgs e)
        {
            if (MSendB.Checked == true)
            {
                MBinary.ReadOnly = false;
                MAddress.ReadOnly = true;
                MMessageT.ReadOnly = true;
                MMessageDL.ReadOnly = true;
                MData.ReadOnly = true;
                MSendE.Enabled = false;
                MValidC.Enabled = false;
                MBinary.BackColor = Color.White;
            }else{
                MBinary.ReadOnly = true;
                MAddress.ReadOnly = false;
                MMessageT.ReadOnly = false;
                MMessageDL.ReadOnly = false;
                MData.ReadOnly = false;
                MCorrectP.Enabled = true;
                MSendE.Enabled = true;
                MValidC.Enabled = true;
                MBinary.BackColor = Color.LightGray;
            }
        }

        //enable or disable the manual data length based on if user wants to auto calculate
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (MAutoDL.Checked == true)
                MMessageDL.ReadOnly = true;
            else
                MMessageDL.ReadOnly = false;
        }

        //run the send method to the appropriate tab
        private void button1_Click(object sender, EventArgs e)
        {
            if (RBRandData.Checked == true)
                SendRandom();
            else if (RBRandWPropStruct.Checked == true)
                SendStructRandom();
            else if (RBManual.Checked == true)
                SendManual();
            else
            {
                    MessageBox.Show("Invalid tab index called");
            }
        }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//---------------------------------------- Random ----------------------------------------------------------------------//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        private int SendRandom()
        {
            //variable declarations
            int baud = convertBaudRate(RBaudR.Text); //convert the baud rate from k to normal
            Random Randnumstart = new Random(); //start the random number generator
            int randnum = Randnumstart.Next(1, 65); //get a new value from the random number generator
            

            byte[] bytestosend = new byte[randnum]; //use the random number generator to tell how much data we are going to send
            for (int i = 0; i < randnum; i++)
            {
                bytestosend[i] = (byte)Randnumstart.Next(0, 256); //add bytes onto the data byte array
            }

            SendToSerial(bytestosend, baud, RCorrectP.Checked); //send the output to the serial line
            return 1; //return no errors
        }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//---------------------------------------- Random Structure ------------------------------------------------------------//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        private int SendStructRandom()
        {
            //Declare needed variables
            Random Randnumstart = new Random(); //random number generator
            int randcommand = Randnumstart.Next(1, 2); //gets a random number to get a random command
            int randdatalength = Randnumstart.Next(0, 129); //get a random length for the data
            int randdata = 0; //this value changes based on time, and is used for generating a random data string
            byte[] messagelength = new byte[4]; //represents the data length in ASCII

            int BaudR = convertBaudRate(RBaudR.Text);//get the baud rate
            byte[] address; //declare teh address byte array

            {
                address = new byte[2];
                for(int i =0; i < 2; i++)
                {
                    address[i] = (byte)Randnumstart.Next(0, 256);
                }
            }


            //get the command
            string MsgType = "";

            {
                for (int i = 0; i < 4; i++)
                {
                    randcommand = Randnumstart.Next(65, 91);
                    MsgType += (char)randcommand;
                }
            }
            byte[] messagetype = converttobitarray(MsgType);//convert the message type/command into a bit array


            //Make random data, and put it in a byte array
            byte[] randdatabytes = new byte[randdatalength];
            for (int i = 0; i < randdatalength; i++)
            {
                randdata = Randnumstart.Next(0, 256);
                randdatabytes[i] = (byte)randdata;
            }


            //make a byte array representing the length of the data bytes array
            string mlength = randdatabytes.Length.ToString();
            
            {
                messagelength[0] = (byte)Randnumstart.Next(0, 256);
                messagelength[1] = (byte)Randnumstart.Next(0, 256);
                messagelength[2] = (byte)Randnumstart.Next(0, 256);
                messagelength[3] = (byte)Randnumstart.Next(0, 256);
            }

           


            //create the primary set of data so that we can calculate the checksum
            byte[] primarydata = new byte[address.Length + messagelength.Length + messagetype.Length + randdatabytes.Length];
            for(int i = 0; i < primarydata.Length; i++)
            {
                if(i < address.Length)
                    primarydata[i] = address[i];
                else if (i < (address.Length + messagetype.Length))
                    primarydata[i] = messagetype[i - (address.Length)];
                else if (i < (address.Length + messagetype.Length + messagelength.Length))
                    primarydata[i] = messagelength[i - (address.Length + messagetype.Length)];
                else if (i < (address.Length + messagetype.Length + messagelength.Length+randdatabytes.Length))
                    primarydata[i] = randdatabytes[i - (address.Length + messagetype.Length + messagelength.Length)];
            }

            //calculate the checksum based on the primary data
            byte[] checksum = new byte[4];

             //otherwise create a random checksum
            {
                checksum[0] = (byte)Randnumstart.Next(0, 256);
                checksum[1] = (byte)Randnumstart.Next(0, 256);
                checksum[2] = (byte)Randnumstart.Next(0, 256);
                checksum[3] = (byte)Randnumstart.Next(0, 256);
            }

            
            //prepare the data to be sent by appending the checksum and EOL
            byte[] datatosend;
            if(RSCorrectP.Checked == true)
                datatosend = new byte[primarydata.Length + checksum.Length + 1];
            else
                datatosend = new byte[primarydata.Length + checksum.Length];

            
            if(RSCorrectP.Checked == true)
            {
                 for(int i = 0; i < datatosend.Length; i++)
                 {
                     if (i < primarydata.Length)
                         datatosend[i] = primarydata[i];
                     else if (i >= primarydata.Length && i < datatosend.Length-1)
                         datatosend[i] = checksum[i - primarydata.Length];
                     else
                         datatosend[i] = (byte)13;
                 }
            }
            else
            {
                for(int i = 0; i < datatosend.Length; i++)
                {
                    if (i < primarydata.Length)
                        datatosend[i] = primarydata[i];
                    else
                        datatosend[i] = checksum[i - primarydata.Length];
                }
            }

            

            //send this data to the bus
            SendToSerial(datatosend, (int)BaudR, RSCorrectP.Checked);

            //return with no errors
            return 1;
        }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//----------------------------------------- Manual ---------------------------------------------------------------------//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        private int SendManual()
        {
            int baud = convertBaudRate(MBaudR.Text); //set the baudrate this is used in both cases
            if (!MSendB.Checked) //if the user is not sending binary
            {
                //Variables
                byte[] DataToSend;
                byte[] Address = converttobitarray(MAddress.Text.Substring(0, 2));
                byte[] MessageType = converttobitarray(MMessageT.Text.Substring(0, 4));
                byte[] Data;
                if (MSpamRand.Checked == false)
                {
                   Data = converttobitarraynonewline(MData.Text);
                }
                else
                {
                   Data = createranddata();
                }
                byte CheckSum = 0;
                byte[] MessageLength = new byte[4];
                string MessLength;
                byte EOL = (byte)13;
                byte[] PrimaryData;
                int chksum = 0;

                //make the data byte array to the right size based on wether autocalculate is turned on or not
                if (MAutoDL.Checked == true)
                {
                    MessLength = (Address.Length + MessageType.Length + Data.Length + 4 + 1 + 1).ToString(); //one for EOL, one for checksum, and four for the data length
                }
                else
                {
                    MessLength = MMessageDL.Text;
                }

                int zero = 0;
                if (MAutoDL.Checked == true)
                {
                    for (int i = 0; i < (5 - MessLength.Length); i++)
                    {
                        MessLength = zero.ToString() + MessLength;
                    }
                }
                char[] mess = MessLength.ToCharArray();
                char char3 = mess[3];
                char char2 = mess[2];
                char char1 = mess[1];
                char char0 = mess[0];
                MessageLength[0] = (byte)char0;
                MessageLength[1] = (byte)char1;
                MessageLength[2] = (byte)char2;
                MessageLength[3] = (byte)char3;
               


                PrimaryData = new byte[Address.Length + MessageType.Length+ MessageLength.Length + Data.Length];//make the primarydata array the correct size
                for (int i = 0; i < PrimaryData.Length; i++)
                {
                    if (i < Address.Length)
                        PrimaryData[i] = Address[i];
                    else if (i < (Address.Length + MessageType.Length))
                        PrimaryData[i] = MessageType[i - (Address.Length)];
                    else if (i < (Address.Length + MessageType.Length + MessageLength.Length))
                        PrimaryData[i] = MessageLength[i - (Address.Length + MessageType.Length)];
                    else if (i < (Address.Length + MessageType.Length + MessageLength.Length + Data.Length))
                        PrimaryData[i] = Data[i - (Address.Length + MessageType.Length + MessageLength.Length)];
                }


                //calculate 32 bit ASCII HEX checksum (2 Hex values)
                if (MValidC.Checked == true)
                {
                    for (int i = 0; i < PrimaryData.Length; i++)
                    {
                        chksum += (int)PrimaryData[i];
                    }
                    for (; chksum > 255; chksum -= 256)
                    {
                        chksum -= 0; //occupy space
                    }
                    CheckSum = (byte)chksum;
                
                }
                else //otherwise create a random checksum
                {
                    Random Randnumstart = new Random();
                    CheckSum = (byte)Randnumstart.Next(0, 256);
                }

                //If sending end of line character
                if (MSendE.Checked == true)
                {
                    DataToSend = new byte[PrimaryData.Length + 1 + 1]; //1 for the checksum, and one for the eol
                    for (int i = 0; i < DataToSend.Length; i++)
                    {
                        if (i < PrimaryData.Length)
                            DataToSend[i] = PrimaryData[i];
                        else if (i >= PrimaryData.Length && i < DataToSend.Length - 1)
                            DataToSend[i] = CheckSum;
                        else
                            DataToSend[i] = EOL;
                    }
                }
                else
                {
                    DataToSend = new byte[PrimaryData.Length + 1]; //one for the checksum
                    for (int i = 0; i < DataToSend.Length; i++)
                    {
                        if (i < PrimaryData.Length)
                            DataToSend[i] = PrimaryData[i];
                        else
                            DataToSend[i] = CheckSum;
                    }
                }

                SendToSerial(DataToSend, baud, MCorrectP.Checked);//send the data to the serial port
                return 1; //return no error
            }
            else //if the user is sending pure binary data
            {
                char onebin;
                int bytecount = 0;
                char[] inbinary = MBinary.Text.ToCharArray();
                string bite = "";
                byte[] outbytes = new byte[0];
                byte[] tempbytes;

                if (MBinary.Text.Length % 8 != 0)
                {
                    MessageBox.Show("Invalid Binary Entry");
                    return 0;// return errors
                }

                for(int k = 0; (k*8) < MBinary.Text.Length; k++){
                    for (int i = 0; i < 8; i++)
                    {
                        onebin = inbinary[(i + (k * 8))]; //get the current index for the input binary array
                        if ((int.Parse(onebin.ToString()) == 0 || int.Parse(onebin.ToString()) == 1) && bytecount < 8) //make sure that the character is 1 or 0 and that the number of bytes is not >8
                        {
                            bite += onebin;
                            bytecount++;
                        }
                        else
                            break;

                    }

                    bytecount = 0; //reset the byte counter
                    // add one index to the outbytes array, and then fill that last index with one byte of data
                    tempbytes = outbytes;
                    outbytes = new byte[tempbytes.Length + 1];
                    for (int i = 0; i < tempbytes.Length; i++)
                    {
                        outbytes[i] = tempbytes[i];
                    }                  
                    outbytes[outbytes.Length - 1] = converttobyte(bite);
                    bite = "";


                }

                SendToSerial(outbytes, baud, MCorrectP.Checked);
                return 1; //return no errors
                
            }
        }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//---------------------------------------- Helper Functions ------------------------------------------------------------//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        //Create 16 messages 4 ASCII characters in length
        private byte[] createranddata()
        {
            Random Randnumstart = new Random(); //start the random number generator
            int randnum;
            int randnum2;
            int randnum3;
            byte[] Data = new byte[(8*4)];
            byte[] tempdata;
            byte onebyte;
            bool bytechanged = false;

            for (int i = 0; i < (8 * 4); i++)
            {
                randnum = Randnumstart.Next(48, 58);
                randnum2 = Randnumstart.Next(65, 71);
                randnum3 = Randnumstart.Next(0, 2);
                switch (randnum3)
                {
                    case 0:
                        onebyte = (byte)randnum;
                        break;
                    case 1:
                        onebyte = (byte)randnum2;
                        break;
                    default:
                        onebyte = (byte)randnum;
                        break;
                }
                Data[i] = onebyte;
                onebyte = (byte)0;
            }
            for (int i = 0; i < Data.Length; i++)
            {
                if (i % 5 == 0)
                {
                    tempdata = Data;
                    Data = new byte[tempdata.Length + 1];
                    for (int j = 0; j < Data.Length - 1; j++)
                    {
                        if (bytechanged == true)
                        {
                            Data[j + 1] = tempdata[j];
                        }
                        else if (j == i)
                        {
                            Data[j] = (byte)32;
                            Data[j + 1] = tempdata[j];
                            bytechanged = true;
                        }
                        else
                        {
                            Data[j] = tempdata[j];
                        }
                    }
                    bytechanged = false;
                }
            }
            tempdata = Data;
            Data = new byte[tempdata.Length - 1];
            for (int i = 0; i < Data.Length; i++)
            {
                Data[i] = tempdata[i + 1];
            }

            return Data;       
        }

        //convert a string of binary numbers to a byte (works for values under 11111111)
        private byte converttobyte(string bits)
        {
            int bit = 0;
            int dec = 0;
            double pow2 = 0;

            for (int i = 0; i < bits.Length; i++)
            {
                bit = int.Parse(bits.Substring(i, 1));
                pow2 = Math.Pow(2, (7-i));
                dec += (int)(bit * pow2);
            }
            return (byte) dec ;
        }

        //Send data to the serial port and post to listboxes
        private int SendToSerial(byte[] Data, int baud, bool parity)
        {
            serialPort1.BaudRate = baud;
            if (parity == true)
                serialPort1.Parity = System.IO.Ports.Parity.Odd;
            else
                serialPort1.Parity = System.IO.Ports.Parity.None;



            try
            {
                COM.ReadOnly = true;
                serialPort1.Write(Data, 0, Data.Length-1);

                string item = "";
                for (int i = 0; i < Data.Length; i++)
                {
                    item += Data[i].ToString() + ", ";
                }

                PCB.Text += Environment.NewLine + Environment.NewLine + item;

                item = "";
                for (int i = 0; i < Data.Length; i++)
                {
                    item += (char)Data[i] + ", ";
                }

                PCAscii.Text += Environment.NewLine + Environment.NewLine + item;
                //serialPort1.Close();
            }
            catch
            {
                MessageBox.Show("Something went wrong...");
                COM.ReadOnly = false;
            }
            

            return 1;
        }

        //Function to convert strings to ASCII, and then make that a bit array
        private byte[] converttobitarray(string input)
        {
            input = input.ToUpper();
            byte[] bytes = new byte[input.Length];
            for (int i = 0; i < input.Length; i++)
            {
                char[] characters = input.ToCharArray();
                char character = characters[i];
                int ascii = (int)character;
                bytes[i] = (byte)ascii;
            }
            return bytes;
        }
        
        //same as convert to bit array, but removes new line characters
        private byte[] converttobitarraynonewline(string input)
        {
            byte[] tempbytes;
            input = input.ToUpper();
            byte[] bytes = new byte[input.Length];
            for (int i = 0; i < input.Length; i++)
            {
                char[] characters = input.ToCharArray();
                char character = characters[i];
                int ascii = (int)character;
                bytes[i] = (byte)ascii;
            }

            //remove ascii codes 10
            for(int i = 0; i < bytes.Length; i++){
                if (int.Parse(bytes[i].ToString()) == 10 /*|| int.Parse(bytes[i].ToString()) == 13*/)
                {
                    tempbytes = bytes;
                    bool removedbyte = false;
                    bytes = new byte[tempbytes.Length - 1];
                    for (int k = 0; k < tempbytes.Length; k++)
                    {
                        if (k == i)
                        {
                            removedbyte = true;
                        }
                        else
                        {
                            if (!removedbyte)
                            {
                                bytes[k] = tempbytes[k];
                            }
                            else
                            {
                                bytes[k - 1] = tempbytes[k];
                            }
                        }
                    }
                    i -= 1;
                }
            }
           
            for (int i = 0; i < bytes.Length; i++)
            {
                if (int.Parse(bytes[i].ToString()) == 13)
                {
                    bytes[i] = 32;
                }
            }
            
            return bytes;
        }

        //convert baud rate from thousands form, to a decimal integer
        private int convertBaudRate(string BaudRstr)
        {        
            double BaudR;
            if (double.TryParse(BaudRstr, out BaudR))
                return (int)(BaudR * 1000);
            else
                return -1;
        }

        private void COM_Leave(object sender, EventArgs e)
        {
            try
            {
                serialPort1.PortName = "COM" + COM.Text;
                serialPort1.Open();
                COM.ReadOnly = true;
            }
            catch
            {
                MessageBox.Show("Invalid COM Number");
                COM.ReadOnly = false;
                COM.Focus();
            }

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }




//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//------------------------------------------ End Of Code ---------------------------------------------------------------//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
    }
}
